# Monopoly
Emulator for a text-based game of Monopoly
