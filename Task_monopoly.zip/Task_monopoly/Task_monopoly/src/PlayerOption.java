public abstract class PlayerOption {
    String message;

    public PlayerOption(String message){
        this.message = message;
    }

    abstract public void action();

    public String toString(){
        return message;
    }
}

class ListPropertiesOption extends PlayerOption{
    Player player;

    public ListPropertiesOption(Player currentPlayer){
        super("Список недвижимости");
        player = currentPlayer;
    }

    public void action(){
        player.listProperties();
    }
}

class BuyHouseOption extends PlayerOption{
    Player player;

    public BuyHouseOption(Player currentPlayer){
        super("Покупайте дома");
        player = currentPlayer;
    }

    public void action(){
        ColorProperty houseProperty = (ColorProperty) Input.selectOptions(player.getHouseableProperties(), "Выберите недвижимость для покупки дома на:");

        if(houseProperty == null){
            System.out.println("У вас нет никаких объектов недвижимости, на которых можно было бы разместить дом");
        } else {
            houseProperty.addHouse();
        }
    }
}

class MortgageOption extends PlayerOption {
    Player player;

    public MortgageOption(Player currentPlayer){
        super("Ипотечная недвижимость");
        player = currentPlayer;
    }

    public void action(){
        Property mortgageProperty = (Property) Input.selectOptions(player.getUnimprovedProperties(), "Выберите не улучшенное свойство");

        if(mortgageProperty == null){
            System.out.println("У вас нет какой-либо незавершенной недвижимости, которую можно было бы заложить");
        } else {
            player.mortgage(mortgageProperty);
        }
    }
}

class PayMortgageOption extends PlayerOption {
    Player player;

    public PayMortgageOption(Player currentPlayer){
        super("Выплачивать ипотеку");
        player = currentPlayer;
    }

    public void action(){
        Property payMortProperty = (Property) Input.selectOptions(player.getMortgagedProperties(), "Выберите недвижимость для погашения ипотеки");

        if(payMortProperty == null){
            System.out.println("У вас нет никакой заложенной недвижимости");
        } else {
            player.payMortgage(payMortProperty);
        }
    }
}

class SellPropertyOption extends PlayerOption {
    Player player;

    public SellPropertyOption(Player currentPlayer){
        super("Продавать не улучшенную недвижимость");
        player = currentPlayer;
    }

    public void action(){
        Property sellProperty = (Property) Input.selectOptions(player.getUnimprovedProperties(), "Выберите недвижимость для продажи");

        if(sellProperty == null){
            System.out.println("У вас нет недвижимости для продажи.");
        } else {
            player.sell(sellProperty);
        }
    }
}

class EndTurnOption extends PlayerOption{
    Game game;
    Player player;

    public EndTurnOption(Game game, Player currentPlayer){
        super("Конец хода");
        this.game = game;
        player = currentPlayer;
    }

    public void action(){
        game.endTurn(player);
    }
}

class PayBailOption extends PlayerOption{
    Dice dice;
    Player player;
    Board board;

    public PayBailOption(Dice dice, Player currentPlayer, Board board){
        super("Заплати $50");
        this.dice = dice;
        player = currentPlayer;
        this.board = board;
    }

    public void action(){
        player.addMoney(-50);
        player.inJail = false;
        player.move(dice.roll(), board);
    }
}

class RollOptionJail extends PlayerOption{
    Dice dice;
    Player player;
    Board board;

    public RollOptionJail(Dice dice, Player currentPlayer, Board board){
        super("Прокрутка");
        this.dice = dice;
        player = currentPlayer;
        this.board = board;
    }

    public void action(){
        int roll = dice.roll();

        if(dice.isDouble()){
            player.inJail = false;
            player.move(roll, board);
        }
    }
}
