import java.util.Arrays;
import java.util.List;

public class Jail{
    private Game game;

    public void setGame(Game game){
        this.game = game;
    }

    public void sendToJail(Player jailedPlayer){
        jailedPlayer.inJail = true;
        System.out.println("Теперь вы находитесь в тюрьме на следующие 3 хода");
        game.endTurn(jailedPlayer);
    }

    public boolean jailTurn(Player currentPlayer, Dice dice, Board board){ //returns true if player escaped jail on turn
        currentPlayer.turnsInJail++;
        System.out.print("Ход " + currentPlayer.turnsInJail);

        if(currentPlayer.turnsInJail == 3){
            currentPlayer.inJail = false;

            int roll = dice.roll();
            if(!dice.isDouble()){
                currentPlayer.addMoney(-50);
            }

            currentPlayer.move(roll, board);
        }

        List<PlayerOption> jailOptions = Arrays.asList(
                new RollOptionJail(dice, currentPlayer, board),
                new PayBailOption(dice, currentPlayer, board)
        );

        PlayerOption selectedOption = (PlayerOption) Input.selectOptions(jailOptions, "Сделайте двойной бросок или заплатите 50 долларов, чтобы сбежать");
        selectedOption.action();

        return currentPlayer.inJail;
    }
}
